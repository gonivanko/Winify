<?php

namespace App;

enum Condition: string
{
    case NEW = 'new';
    case USED = 'used';
}
